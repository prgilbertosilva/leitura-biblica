window.LEITURAS_DATA = [
  {
    "date": "2026-04-07",
    "oldTestament": "Deuteronômio 33–34",
    "wisdom": "Salmo 97",
    "newTestament": "Atos 8",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de Deuteronômio 33–34, Salmo 97 e Atos 8 destacam a fidelidade de Deus e nos chamam a responder com fé, obediência e esperança em Cristo."
  },
  {
    "date": "2026-04-08",
    "oldTestament": "Josué 1–3",
    "wisdom": "Salmo 98",
    "newTestament": "Atos 9:1–19",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em Josué 1–3, Salmo 98 e Atos 9:1–19, somos lembrados de buscar a direção do Senhor e caminhar com um coração atento à sua Palavra."
  },
  {
    "date": "2026-04-09",
    "oldTestament": "Josué 4–6",
    "wisdom": "Salmo 99",
    "newTestament": "Atos 9:20–43",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Josué 4–6, Salmo 99 e Atos 9:20–43 nos convidam a confiar no cuidado de Deus e a viver uma fé prática, perseverante e cheia de esperança."
  },
  {
    "date": "2026-04-10",
    "oldTestament": "Josué 7–9",
    "wisdom": "Salmo 100",
    "newTestament": "Atos 10:1–23",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de Josué 7–9, Salmo 100 e Atos 10:1–23 apontam para a santidade de Deus e nos encorajam a permanecer firmes no caminho do Senhor."
  },
  {
    "date": "2026-04-11",
    "oldTestament": "Josué 10–12",
    "wisdom": "Salmo 101",
    "newTestament": "Atos 10:24–48",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em Josué 10–12, Salmo 101 e Atos 10:24–48, a Palavra nos chama a depender da graça de Deus e a transformar a leitura em vida obediente."
  },
  {
    "date": "2026-04-12",
    "oldTestament": "Josué 13–15",
    "wisdom": "Salmo 102",
    "newTestament": "Atos 11",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Josué 13–15, Salmo 102 e Atos 11 nos ajudam a enxergar o agir de Deus na história e a renovar nossa confiança nele a cada dia."
  },
  {
    "date": "2026-04-13",
    "oldTestament": "Josué 16–18",
    "wisdom": "Salmo 103",
    "newTestament": "Atos 12",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de Josué 16–18, Salmo 103 e Atos 12 destacam a fidelidade de Deus e nos chamam a responder com fé, obediência e esperança em Cristo."
  },
  {
    "date": "2026-04-14",
    "oldTestament": "Josué 19–21",
    "wisdom": "Salmo 104",
    "newTestament": "Atos 13:1–25",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em Josué 19–21, Salmo 104 e Atos 13:1–25, somos lembrados de buscar a direção do Senhor e caminhar com um coração atento à sua Palavra."
  },
  {
    "date": "2026-04-15",
    "oldTestament": "Josué 22–24",
    "wisdom": "Salmo 105",
    "newTestament": "Atos 13:26–52",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Josué 22–24, Salmo 105 e Atos 13:26–52 nos convidam a confiar no cuidado de Deus e a viver uma fé prática, perseverante e cheia de esperança."
  },
  {
    "date": "2026-04-16",
    "oldTestament": "Juízes 1–3",
    "wisdom": "Salmo 106",
    "newTestament": "Atos 14",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de Juízes 1–3, Salmo 106 e Atos 14 apontam para a santidade de Deus e nos encorajam a permanecer firmes no caminho do Senhor."
  },
  {
    "date": "2026-04-17",
    "oldTestament": "Juízes 4–6",
    "wisdom": "Salmo 107",
    "newTestament": "Atos 15:1–21",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em Juízes 4–6, Salmo 107 e Atos 15:1–21, a Palavra nos chama a depender da graça de Deus e a transformar a leitura em vida obediente."
  },
  {
    "date": "2026-04-18",
    "oldTestament": "Juízes 7–9",
    "wisdom": "Salmo 108",
    "newTestament": "Atos 15:22–41",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Juízes 7–9, Salmo 108 e Atos 15:22–41 nos ajudam a enxergar o agir de Deus na história e a renovar nossa confiança nele a cada dia."
  },
  {
    "date": "2026-04-19",
    "oldTestament": "Juízes 10–12",
    "wisdom": "Salmo 109",
    "newTestament": "Atos 16:1–15",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de Juízes 10–12, Salmo 109 e Atos 16:1–15 destacam a fidelidade de Deus e nos chamam a responder com fé, obediência e esperança em Cristo."
  },
  {
    "date": "2026-04-20",
    "oldTestament": "Juízes 13–15",
    "wisdom": "Salmo 110",
    "newTestament": "Atos 16:16–40",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em Juízes 13–15, Salmo 110 e Atos 16:16–40, somos lembrados de buscar a direção do Senhor e caminhar com um coração atento à sua Palavra."
  },
  {
    "date": "2026-04-21",
    "oldTestament": "Juízes 16–18",
    "wisdom": "Salmo 111",
    "newTestament": "Atos 17:1–15",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Juízes 16–18, Salmo 111 e Atos 17:1–15 nos convidam a confiar no cuidado de Deus e a viver uma fé prática, perseverante e cheia de esperança."
  },
  {
    "date": "2026-04-22",
    "oldTestament": "Juízes 19–21",
    "wisdom": "Salmo 112",
    "newTestament": "Atos 17:16–34",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de Juízes 19–21, Salmo 112 e Atos 17:16–34 apontam para a santidade de Deus e nos encorajam a permanecer firmes no caminho do Senhor."
  },
  {
    "date": "2026-04-23",
    "oldTestament": "Rute 1–4",
    "wisdom": "Salmo 113",
    "newTestament": "Atos 18",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em Rute 1–4, Salmo 113 e Atos 18, a Palavra nos chama a depender da graça de Deus e a transformar a leitura em vida obediente."
  },
  {
    "date": "2026-04-24",
    "oldTestament": "1 Samuel 1–3",
    "wisdom": "Salmo 114",
    "newTestament": "Atos 19:1–20",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "1 Samuel 1–3, Salmo 114 e Atos 19:1–20 nos ajudam a enxergar o agir de Deus na história e a renovar nossa confiança nele a cada dia."
  },
  {
    "date": "2026-04-25",
    "oldTestament": "1 Samuel 4–6",
    "wisdom": "Salmo 115",
    "newTestament": "Atos 19:21–41",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de 1 Samuel 4–6, Salmo 115 e Atos 19:21–41 destacam a fidelidade de Deus e nos chamam a responder com fé, obediência e esperança em Cristo."
  },
  {
    "date": "2026-04-26",
    "oldTestament": "1 Samuel 7–9",
    "wisdom": "Salmo 116",
    "newTestament": "Atos 20:1–16",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em 1 Samuel 7–9, Salmo 116 e Atos 20:1–16, somos lembrados de buscar a direção do Senhor e caminhar com um coração atento à sua Palavra."
  },
  {
    "date": "2026-04-27",
    "oldTestament": "1 Samuel 10–12",
    "wisdom": "Salmo 117",
    "newTestament": "Atos 20:17–38",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "1 Samuel 10–12, Salmo 117 e Atos 20:17–38 nos convidam a confiar no cuidado de Deus e a viver uma fé prática, perseverante e cheia de esperança."
  },
  {
    "date": "2026-04-28",
    "oldTestament": "1 Samuel 13–15",
    "wisdom": "Salmo 118",
    "newTestament": "Atos 21:1–16",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de 1 Samuel 13–15, Salmo 118 e Atos 21:1–16 apontam para a santidade de Deus e nos encorajam a permanecer firmes no caminho do Senhor."
  },
  {
    "date": "2026-04-29",
    "oldTestament": "1 Samuel 16–18",
    "wisdom": "Salmo 119:1–88",
    "newTestament": "Atos 21:17–40",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em 1 Samuel 16–18, Salmo 119:1–88 e Atos 21:17–40, a Palavra nos chama a depender da graça de Deus e a transformar a leitura em vida obediente."
  },
  {
    "date": "2026-04-30",
    "oldTestament": "1 Samuel 19–21",
    "wisdom": "Salmo 119:89–176",
    "newTestament": "Atos 22",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "1 Samuel 19–21, Salmo 119:89–176 e Atos 22 nos ajudam a enxergar o agir de Deus na história e a renovar nossa confiança nele a cada dia."
  },
  {
    "date": "2026-05-01",
    "oldTestament": "1 Samuel 22–24",
    "wisdom": "Salmo 120",
    "newTestament": "Atos 23",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de 1 Samuel 22–24, Salmo 120 e Atos 23 destacam a fidelidade de Deus e nos chamam a responder com fé, obediência e esperança em Cristo."
  },
  {
    "date": "2026-05-02",
    "oldTestament": "1 Samuel 25–27",
    "wisdom": "Salmo 121",
    "newTestament": "Atos 24",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em 1 Samuel 25–27, Salmo 121 e Atos 24, somos lembrados de buscar a direção do Senhor e caminhar com um coração atento à sua Palavra."
  },
  {
    "date": "2026-05-03",
    "oldTestament": "1 Samuel 28–31",
    "wisdom": "Salmo 122",
    "newTestament": "Atos 25",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "1 Samuel 28–31, Salmo 122 e Atos 25 nos convidam a confiar no cuidado de Deus e a viver uma fé prática, perseverante e cheia de esperança."
  },
  {
    "date": "2026-05-04",
    "oldTestament": "2 Samuel 1–3",
    "wisdom": "Salmo 123",
    "newTestament": "Atos 26",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de 2 Samuel 1–3, Salmo 123 e Atos 26 apontam para a santidade de Deus e nos encorajam a permanecer firmes no caminho do Senhor."
  },
  {
    "date": "2026-05-05",
    "oldTestament": "2 Samuel 4–6",
    "wisdom": "Salmo 124",
    "newTestament": "Atos 27:1–26",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em 2 Samuel 4–6, Salmo 124 e Atos 27:1–26, a Palavra nos chama a depender da graça de Deus e a transformar a leitura em vida obediente."
  },
  {
    "date": "2026-05-06",
    "oldTestament": "2 Samuel 7–9",
    "wisdom": "Salmo 125",
    "newTestament": "Atos 27:27–44",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "2 Samuel 7–9, Salmo 125 e Atos 27:27–44 nos ajudam a enxergar o agir de Deus na história e a renovar nossa confiança nele a cada dia."
  },
  {
    "date": "2026-05-07",
    "oldTestament": "2 Samuel 10–12",
    "wisdom": "Salmo 126",
    "newTestament": "Atos 28",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de 2 Samuel 10–12, Salmo 126 e Atos 28 destacam a fidelidade de Deus e nos chamam a responder com fé, obediência e esperança em Cristo."
  },
  {
    "date": "2026-05-08",
    "oldTestament": "2 Samuel 13–15",
    "wisdom": "Salmo 127",
    "newTestament": "Romanos 1",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em 2 Samuel 13–15, Salmo 127 e Romanos 1, somos lembrados de buscar a direção do Senhor e caminhar com um coração atento à sua Palavra."
  },
  {
    "date": "2026-05-09",
    "oldTestament": "2 Samuel 16–18",
    "wisdom": "Salmo 128",
    "newTestament": "Romanos 2",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "2 Samuel 16–18, Salmo 128 e Romanos 2 nos convidam a confiar no cuidado de Deus e a viver uma fé prática, perseverante e cheia de esperança."
  },
  {
    "date": "2026-05-10",
    "oldTestament": "2 Samuel 19–21",
    "wisdom": "Salmo 129",
    "newTestament": "Romanos 3",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de 2 Samuel 19–21, Salmo 129 e Romanos 3 apontam para a santidade de Deus e nos encorajam a permanecer firmes no caminho do Senhor."
  },
  {
    "date": "2026-05-11",
    "oldTestament": "2 Samuel 22–24",
    "wisdom": "Salmo 130",
    "newTestament": "Romanos 4",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em 2 Samuel 22–24, Salmo 130 e Romanos 4, a Palavra nos chama a depender da graça de Deus e a transformar a leitura em vida obediente."
  },
  {
    "date": "2026-05-12",
    "oldTestament": "1 Reis 1–3",
    "wisdom": "Salmo 131",
    "newTestament": "Romanos 5",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "1 Reis 1–3, Salmo 131 e Romanos 5 nos ajudam a enxergar o agir de Deus na história e a renovar nossa confiança nele a cada dia."
  },
  {
    "date": "2026-05-13",
    "oldTestament": "1 Reis 4–6",
    "wisdom": "Salmo 132",
    "newTestament": "Romanos 6",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de 1 Reis 4–6, Salmo 132 e Romanos 6 destacam a fidelidade de Deus e nos chamam a responder com fé, obediência e esperança em Cristo."
  },
  {
    "date": "2026-05-14",
    "oldTestament": "1 Reis 7–9",
    "wisdom": "Salmo 133",
    "newTestament": "Romanos 7",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em 1 Reis 7–9, Salmo 133 e Romanos 7, somos lembrados de buscar a direção do Senhor e caminhar com um coração atento à sua Palavra."
  },
  {
    "date": "2026-05-15",
    "oldTestament": "1 Reis 10–12",
    "wisdom": "Salmo 134",
    "newTestament": "Romanos 8:1–17",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "1 Reis 10–12, Salmo 134 e Romanos 8:1–17 nos convidam a confiar no cuidado de Deus e a viver uma fé prática, perseverante e cheia de esperança."
  },
  {
    "date": "2026-05-16",
    "oldTestament": "1 Reis 13–15",
    "wisdom": "Salmo 135",
    "newTestament": "Romanos 8:18–39",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de 1 Reis 13–15, Salmo 135 e Romanos 8:18–39 apontam para a santidade de Deus e nos encorajam a permanecer firmes no caminho do Senhor."
  },
  {
    "date": "2026-05-17",
    "oldTestament": "1 Reis 16–18",
    "wisdom": "Salmo 136",
    "newTestament": "Romanos 9",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em 1 Reis 16–18, Salmo 136 e Romanos 9, a Palavra nos chama a depender da graça de Deus e a transformar a leitura em vida obediente."
  },
  {
    "date": "2026-05-18",
    "oldTestament": "1 Reis 19–21",
    "wisdom": "Salmo 137",
    "newTestament": "Romanos 10",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "1 Reis 19–21, Salmo 137 e Romanos 10 nos ajudam a enxergar o agir de Deus na história e a renovar nossa confiança nele a cada dia."
  },
  {
    "date": "2026-05-19",
    "oldTestament": "1 Reis 22 + 2 Reis 1–2",
    "wisdom": "Salmo 138",
    "newTestament": "Romanos 11",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de 1 Reis 22 + 2 Reis 1–2, Salmo 138 e Romanos 11 destacam a fidelidade de Deus e nos chamam a responder com fé, obediência e esperança em Cristo."
  },
  {
    "date": "2026-05-20",
    "oldTestament": "2 Reis 3–5",
    "wisdom": "Salmo 139",
    "newTestament": "Romanos 12",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em 2 Reis 3–5, Salmo 139 e Romanos 12, somos lembrados de buscar a direção do Senhor e caminhar com um coração atento à sua Palavra."
  },
  {
    "date": "2026-05-21",
    "oldTestament": "2 Reis 6–8",
    "wisdom": "Salmo 140",
    "newTestament": "Romanos 13",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "2 Reis 6–8, Salmo 140 e Romanos 13 nos convidam a confiar no cuidado de Deus e a viver uma fé prática, perseverante e cheia de esperança."
  },
  {
    "date": "2026-05-22",
    "oldTestament": "2 Reis 9–11",
    "wisdom": "Salmo 141",
    "newTestament": "Romanos 14",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de 2 Reis 9–11, Salmo 141 e Romanos 14 apontam para a santidade de Deus e nos encorajam a permanecer firmes no caminho do Senhor."
  },
  {
    "date": "2026-05-23",
    "oldTestament": "2 Reis 12–14",
    "wisdom": "Salmo 142",
    "newTestament": "Romanos 15",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em 2 Reis 12–14, Salmo 142 e Romanos 15, a Palavra nos chama a depender da graça de Deus e a transformar a leitura em vida obediente."
  },
  {
    "date": "2026-05-24",
    "oldTestament": "2 Reis 15–17",
    "wisdom": "Salmo 143",
    "newTestament": "Romanos 16",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "2 Reis 15–17, Salmo 143 e Romanos 16 nos ajudam a enxergar o agir de Deus na história e a renovar nossa confiança nele a cada dia."
  },
  {
    "date": "2026-05-25",
    "oldTestament": "2 Reis 18–20",
    "wisdom": "Salmo 144",
    "newTestament": "1 Coríntios 1",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de 2 Reis 18–20, Salmo 144 e 1 Coríntios 1 destacam a fidelidade de Deus e nos chamam a responder com fé, obediência e esperança em Cristo."
  },
  {
    "date": "2026-05-26",
    "oldTestament": "2 Reis 21–23",
    "wisdom": "Salmo 145",
    "newTestament": "1 Coríntios 2",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em 2 Reis 21–23, Salmo 145 e 1 Coríntios 2, somos lembrados de buscar a direção do Senhor e caminhar com um coração atento à sua Palavra."
  },
  {
    "date": "2026-05-27",
    "oldTestament": "2 Reis 24–25",
    "wisdom": "Salmo 146",
    "newTestament": "1 Coríntios 3",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "2 Reis 24–25, Salmo 146 e 1 Coríntios 3 nos convidam a confiar no cuidado de Deus e a viver uma fé prática, perseverante e cheia de esperança."
  },
  {
    "date": "2026-05-28",
    "oldTestament": "1 Crônicas 1–3",
    "wisdom": "Salmo 147",
    "newTestament": "1 Coríntios 4",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de 1 Crônicas 1–3, Salmo 147 e 1 Coríntios 4 apontam para a santidade de Deus e nos encorajam a permanecer firmes no caminho do Senhor."
  },
  {
    "date": "2026-05-29",
    "oldTestament": "1 Crônicas 4–6",
    "wisdom": "Salmo 148",
    "newTestament": "1 Coríntios 5",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em 1 Crônicas 4–6, Salmo 148 e 1 Coríntios 5, a Palavra nos chama a depender da graça de Deus e a transformar a leitura em vida obediente."
  },
  {
    "date": "2026-05-30",
    "oldTestament": "1 Crônicas 7–9",
    "wisdom": "Salmo 149",
    "newTestament": "1 Coríntios 6",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "1 Crônicas 7–9, Salmo 149 e 1 Coríntios 6 nos ajudam a enxergar o agir de Deus na história e a renovar nossa confiança nele a cada dia."
  },
  {
    "date": "2026-05-31",
    "oldTestament": "1 Crônicas 10–12",
    "wisdom": "Salmo 150",
    "newTestament": "1 Coríntios 7",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de 1 Crônicas 10–12, Salmo 150 e 1 Coríntios 7 destacam a fidelidade de Deus e nos chamam a responder com fé, obediência e esperança em Cristo."
  },
  {
    "date": "2026-06-01",
    "oldTestament": "1 Crônicas 13–15",
    "wisdom": "Provérbios 1",
    "newTestament": "1 Coríntios 8",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em 1 Crônicas 13–15, Provérbios 1 e 1 Coríntios 8, somos lembrados de buscar a direção do Senhor e caminhar com um coração atento à sua Palavra."
  },
  {
    "date": "2026-06-02",
    "oldTestament": "1 Crônicas 16–18",
    "wisdom": "Provérbios 2",
    "newTestament": "1 Coríntios 9",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "1 Crônicas 16–18, Provérbios 2 e 1 Coríntios 9 nos convidam a confiar no cuidado de Deus e a viver uma fé prática, perseverante e cheia de esperança."
  },
  {
    "date": "2026-06-03",
    "oldTestament": "1 Crônicas 19–21",
    "wisdom": "Provérbios 3",
    "newTestament": "1 Coríntios 10",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de 1 Crônicas 19–21, Provérbios 3 e 1 Coríntios 10 apontam para a santidade de Deus e nos encorajam a permanecer firmes no caminho do Senhor."
  },
  {
    "date": "2026-06-04",
    "oldTestament": "1 Crônicas 22–24",
    "wisdom": "Provérbios 4",
    "newTestament": "1 Coríntios 11",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em 1 Crônicas 22–24, Provérbios 4 e 1 Coríntios 11, a Palavra nos chama a depender da graça de Deus e a transformar a leitura em vida obediente."
  },
  {
    "date": "2026-06-05",
    "oldTestament": "1 Crônicas 25–27",
    "wisdom": "Provérbios 5",
    "newTestament": "1 Coríntios 12:1–11",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "1 Crônicas 25–27, Provérbios 5 e 1 Coríntios 12:1–11 nos ajudam a enxergar o agir de Deus na história e a renovar nossa confiança nele a cada dia."
  },
  {
    "date": "2026-06-06",
    "oldTestament": "1 Crônicas 28–29",
    "wisdom": "Provérbios 6",
    "newTestament": "1 Coríntios 12:12–31",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de 1 Crônicas 28–29, Provérbios 6 e 1 Coríntios 12:12–31 destacam a fidelidade de Deus e nos chamam a responder com fé, obediência e esperança em Cristo."
  },
  {
    "date": "2026-06-07",
    "oldTestament": "2 Crônicas 1–3",
    "wisdom": "Provérbios 7",
    "newTestament": "1 Coríntios 13",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em 2 Crônicas 1–3, Provérbios 7 e 1 Coríntios 13, somos lembrados de buscar a direção do Senhor e caminhar com um coração atento à sua Palavra."
  },
  {
    "date": "2026-06-08",
    "oldTestament": "2 Crônicas 4–6",
    "wisdom": "Provérbios 8",
    "newTestament": "1 Coríntios 14:1–20",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "2 Crônicas 4–6, Provérbios 8 e 1 Coríntios 14:1–20 nos convidam a confiar no cuidado de Deus e a viver uma fé prática, perseverante e cheia de esperança."
  },
  {
    "date": "2026-06-09",
    "oldTestament": "2 Crônicas 7–9",
    "wisdom": "Provérbios 9",
    "newTestament": "1 Coríntios 14:21–40",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de 2 Crônicas 7–9, Provérbios 9 e 1 Coríntios 14:21–40 apontam para a santidade de Deus e nos encorajam a permanecer firmes no caminho do Senhor."
  },
  {
    "date": "2026-06-10",
    "oldTestament": "2 Crônicas 10–12",
    "wisdom": "Provérbios 10",
    "newTestament": "1 Coríntios 15:1–28",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em 2 Crônicas 10–12, Provérbios 10 e 1 Coríntios 15:1–28, a Palavra nos chama a depender da graça de Deus e a transformar a leitura em vida obediente."
  },
  {
    "date": "2026-06-11",
    "oldTestament": "2 Crônicas 13–15",
    "wisdom": "Provérbios 11",
    "newTestament": "1 Coríntios 15:29–58",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "2 Crônicas 13–15, Provérbios 11 e 1 Coríntios 15:29–58 nos ajudam a enxergar o agir de Deus na história e a renovar nossa confiança nele a cada dia."
  },
  {
    "date": "2026-06-12",
    "oldTestament": "2 Crônicas 16–18",
    "wisdom": "Provérbios 12",
    "newTestament": "1 Coríntios 16",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de 2 Crônicas 16–18, Provérbios 12 e 1 Coríntios 16 destacam a fidelidade de Deus e nos chamam a responder com fé, obediência e esperança em Cristo."
  },
  {
    "date": "2026-06-13",
    "oldTestament": "2 Crônicas 19–21",
    "wisdom": "Provérbios 13",
    "newTestament": "2 Coríntios 1",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em 2 Crônicas 19–21, Provérbios 13 e 2 Coríntios 1, somos lembrados de buscar a direção do Senhor e caminhar com um coração atento à sua Palavra."
  },
  {
    "date": "2026-06-14",
    "oldTestament": "2 Crônicas 22–24",
    "wisdom": "Provérbios 14",
    "newTestament": "2 Coríntios 2",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "2 Crônicas 22–24, Provérbios 14 e 2 Coríntios 2 nos convidam a confiar no cuidado de Deus e a viver uma fé prática, perseverante e cheia de esperança."
  },
  {
    "date": "2026-06-15",
    "oldTestament": "2 Crônicas 25–27",
    "wisdom": "Provérbios 15",
    "newTestament": "2 Coríntios 3",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de 2 Crônicas 25–27, Provérbios 15 e 2 Coríntios 3 apontam para a santidade de Deus e nos encorajam a permanecer firmes no caminho do Senhor."
  },
  {
    "date": "2026-06-16",
    "oldTestament": "2 Crônicas 28–30",
    "wisdom": "Provérbios 16",
    "newTestament": "2 Coríntios 4",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em 2 Crônicas 28–30, Provérbios 16 e 2 Coríntios 4, a Palavra nos chama a depender da graça de Deus e a transformar a leitura em vida obediente."
  },
  {
    "date": "2026-06-17",
    "oldTestament": "2 Crônicas 31–33",
    "wisdom": "Provérbios 17",
    "newTestament": "2 Coríntios 5",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "2 Crônicas 31–33, Provérbios 17 e 2 Coríntios 5 nos ajudam a enxergar o agir de Deus na história e a renovar nossa confiança nele a cada dia."
  },
  {
    "date": "2026-06-18",
    "oldTestament": "2 Crônicas 34–36",
    "wisdom": "Provérbios 18",
    "newTestament": "2 Coríntios 6",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de 2 Crônicas 34–36, Provérbios 18 e 2 Coríntios 6 destacam a fidelidade de Deus e nos chamam a responder com fé, obediência e esperança em Cristo."
  },
  {
    "date": "2026-06-19",
    "oldTestament": "Esdras 1–3",
    "wisdom": "Provérbios 19",
    "newTestament": "2 Coríntios 7",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em Esdras 1–3, Provérbios 19 e 2 Coríntios 7, somos lembrados de buscar a direção do Senhor e caminhar com um coração atento à sua Palavra."
  },
  {
    "date": "2026-06-20",
    "oldTestament": "Esdras 4–6",
    "wisdom": "Provérbios 20",
    "newTestament": "2 Coríntios 8",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Esdras 4–6, Provérbios 20 e 2 Coríntios 8 nos convidam a confiar no cuidado de Deus e a viver uma fé prática, perseverante e cheia de esperança."
  },
  {
    "date": "2026-06-21",
    "oldTestament": "Esdras 7–10",
    "wisdom": "Provérbios 21",
    "newTestament": "2 Coríntios 9",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de Esdras 7–10, Provérbios 21 e 2 Coríntios 9 apontam para a santidade de Deus e nos encorajam a permanecer firmes no caminho do Senhor."
  },
  {
    "date": "2026-06-22",
    "oldTestament": "Neemias 1–3",
    "wisdom": "Provérbios 22",
    "newTestament": "2 Coríntios 10",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em Neemias 1–3, Provérbios 22 e 2 Coríntios 10, a Palavra nos chama a depender da graça de Deus e a transformar a leitura em vida obediente."
  },
  {
    "date": "2026-06-23",
    "oldTestament": "Neemias 4–6",
    "wisdom": "Provérbios 23",
    "newTestament": "2 Coríntios 11",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Neemias 4–6, Provérbios 23 e 2 Coríntios 11 nos ajudam a enxergar o agir de Deus na história e a renovar nossa confiança nele a cada dia."
  },
  {
    "date": "2026-06-24",
    "oldTestament": "Neemias 7–9",
    "wisdom": "Provérbios 24",
    "newTestament": "2 Coríntios 12",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de Neemias 7–9, Provérbios 24 e 2 Coríntios 12 destacam a fidelidade de Deus e nos chamam a responder com fé, obediência e esperança em Cristo."
  },
  {
    "date": "2026-06-25",
    "oldTestament": "Neemias 10–13",
    "wisdom": "Provérbios 25",
    "newTestament": "2 Coríntios 13",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em Neemias 10–13, Provérbios 25 e 2 Coríntios 13, somos lembrados de buscar a direção do Senhor e caminhar com um coração atento à sua Palavra."
  },
  {
    "date": "2026-06-26",
    "oldTestament": "Ester 1–3",
    "wisdom": "Provérbios 26",
    "newTestament": "Gálatas 1",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Ester 1–3, Provérbios 26 e Gálatas 1 nos convidam a confiar no cuidado de Deus e a viver uma fé prática, perseverante e cheia de esperança."
  },
  {
    "date": "2026-06-27",
    "oldTestament": "Ester 4–6",
    "wisdom": "Provérbios 27",
    "newTestament": "Gálatas 2",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de Ester 4–6, Provérbios 27 e Gálatas 2 apontam para a santidade de Deus e nos encorajam a permanecer firmes no caminho do Senhor."
  },
  {
    "date": "2026-06-28",
    "oldTestament": "Ester 7–10",
    "wisdom": "Provérbios 28",
    "newTestament": "Gálatas 3",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em Ester 7–10, Provérbios 28 e Gálatas 3, a Palavra nos chama a depender da graça de Deus e a transformar a leitura em vida obediente."
  },
  {
    "date": "2026-06-29",
    "oldTestament": "Jó 1–3",
    "wisdom": "Provérbios 29",
    "newTestament": "Gálatas 4",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Jó 1–3, Provérbios 29 e Gálatas 4 nos ajudam a enxergar o agir de Deus na história e a renovar nossa confiança nele a cada dia."
  },
  {
    "date": "2026-06-30",
    "oldTestament": "Jó 4–6",
    "wisdom": "Provérbios 30",
    "newTestament": "Gálatas 5",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de Jó 4–6, Provérbios 30 e Gálatas 5 destacam a fidelidade de Deus e nos chamam a responder com fé, obediência e esperança em Cristo."
  },
  {
    "date": "2026-07-01",
    "oldTestament": "Jó 7–9",
    "wisdom": "Provérbios 31",
    "newTestament": "Gálatas 6",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em Jó 7–9, Provérbios 31 e Gálatas 6, somos lembrados de buscar a direção do Senhor e caminhar com um coração atento à sua Palavra."
  },
  {
    "date": "2026-07-02",
    "oldTestament": "Jó 10–12",
    "wisdom": "",
    "newTestament": "Efésios 1:1–14",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Jó 10–12 e Efésios 1:1–14 nos convidam a confiar no cuidado de Deus e a viver uma fé prática, perseverante e cheia de esperança."
  },
  {
    "date": "2026-07-03",
    "oldTestament": "Jó 13–15",
    "wisdom": "",
    "newTestament": "Efésios 1:15–23",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de Jó 13–15 e Efésios 1:15–23 apontam para a santidade de Deus e nos encorajam a permanecer firmes no caminho do Senhor."
  },
  {
    "date": "2026-07-04",
    "oldTestament": "Jó 16–18",
    "wisdom": "",
    "newTestament": "Efésios 2",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em Jó 16–18 e Efésios 2, a Palavra nos chama a depender da graça de Deus e a transformar a leitura em vida obediente."
  },
  {
    "date": "2026-07-05",
    "oldTestament": "Jó 19–21",
    "wisdom": "",
    "newTestament": "Efésios 3",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Jó 19–21 e Efésios 3 nos ajudam a enxergar o agir de Deus na história e a renovar nossa confiança nele a cada dia."
  },
  {
    "date": "2026-07-06",
    "oldTestament": "Jó 22–24",
    "wisdom": "",
    "newTestament": "Efésios 4",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de Jó 22–24 e Efésios 4 destacam a fidelidade de Deus e nos chamam a responder com fé, obediência e esperança em Cristo."
  },
  {
    "date": "2026-07-07",
    "oldTestament": "Jó 25–27",
    "wisdom": "",
    "newTestament": "Efésios 5",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em Jó 25–27 e Efésios 5, somos lembrados de buscar a direção do Senhor e caminhar com um coração atento à sua Palavra."
  },
  {
    "date": "2026-07-08",
    "oldTestament": "Jó 28–30",
    "wisdom": "",
    "newTestament": "Efésios 6:1–9",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Jó 28–30 e Efésios 6:1–9 nos convidam a confiar no cuidado de Deus e a viver uma fé prática, perseverante e cheia de esperança."
  },
  {
    "date": "2026-07-09",
    "oldTestament": "Jó 31–33",
    "wisdom": "",
    "newTestament": "Efésios 6:10–24",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de Jó 31–33 e Efésios 6:10–24 apontam para a santidade de Deus e nos encorajam a permanecer firmes no caminho do Senhor."
  },
  {
    "date": "2026-07-10",
    "oldTestament": "Jó 34–36",
    "wisdom": "",
    "newTestament": "Filipenses 1",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em Jó 34–36 e Filipenses 1, a Palavra nos chama a depender da graça de Deus e a transformar a leitura em vida obediente."
  },
  {
    "date": "2026-07-11",
    "oldTestament": "Jó 37–39",
    "wisdom": "",
    "newTestament": "Filipenses 2",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Jó 37–39 e Filipenses 2 nos ajudam a enxergar o agir de Deus na história e a renovar nossa confiança nele a cada dia."
  },
  {
    "date": "2026-07-12",
    "oldTestament": "Jó 40–42",
    "wisdom": "",
    "newTestament": "Filipenses 3",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de Jó 40–42 e Filipenses 3 destacam a fidelidade de Deus e nos chamam a responder com fé, obediência e esperança em Cristo."
  },
  {
    "date": "2026-07-13",
    "oldTestament": "Eclesiastes 1–2",
    "wisdom": "",
    "newTestament": "Filipenses 4",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em Eclesiastes 1–2 e Filipenses 4, somos lembrados de buscar a direção do Senhor e caminhar com um coração atento à sua Palavra."
  },
  {
    "date": "2026-07-14",
    "oldTestament": "Eclesiastes 3–4",
    "wisdom": "",
    "newTestament": "Colossenses 1",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Eclesiastes 3–4 e Colossenses 1 nos convidam a confiar no cuidado de Deus e a viver uma fé prática, perseverante e cheia de esperança."
  },
  {
    "date": "2026-07-15",
    "oldTestament": "Eclesiastes 5–6",
    "wisdom": "",
    "newTestament": "Colossenses 2",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de Eclesiastes 5–6 e Colossenses 2 apontam para a santidade de Deus e nos encorajam a permanecer firmes no caminho do Senhor."
  },
  {
    "date": "2026-07-16",
    "oldTestament": "Eclesiastes 7–8",
    "wisdom": "",
    "newTestament": "Colossenses 3",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Eclesiastes ensina que a verdadeira sabedoria molda a maneira como vivemos. Colossenses nos chama a buscar as coisas do alto e a revestir-nos do novo homem. Uma vida transformada começa quando nossa mente e nosso coração estão firmados em Cristo."
  },
  {
    "date": "2026-07-17",
    "oldTestament": "Eclesiastes 9–10",
    "wisdom": "",
    "newTestament": "Colossenses 4",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Eclesiastes nos lembra que a vida ganha sentido quando vivida diante de Deus. Colossenses nos chama a perseverar em oração e a agir com sabedoria. Quem teme ao Senhor aprende a viver com propósito, gratidão e graça."
  },
  {
    "date": "2026-07-18",
    "oldTestament": "Eclesiastes 11–12",
    "wisdom": "",
    "newTestament": "1 Tessalonicenses 1",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de Eclesiastes 11–12 e 1 Tessalonicenses 1 destacam a fidelidade de Deus e nos chamam a responder com fé, obediência e esperança em Cristo."
  },
  {
    "date": "2026-07-19",
    "oldTestament": "Cantares 1–2",
    "wisdom": "",
    "newTestament": "1 Tessalonicenses 2",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em Cantares 1–2 e 1 Tessalonicenses 2, somos lembrados de buscar a direção do Senhor e caminhar com um coração atento à sua Palavra."
  },
  {
    "date": "2026-07-20",
    "oldTestament": "Cantares 3–4",
    "wisdom": "",
    "newTestament": "1 Tessalonicenses 3",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Cantares 3–4 e 1 Tessalonicenses 3 nos convidam a confiar no cuidado de Deus e a viver uma fé prática, perseverante e cheia de esperança."
  },
  {
    "date": "2026-07-21",
    "oldTestament": "Cantares 5–6",
    "wisdom": "",
    "newTestament": "1 Tessalonicenses 4",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de Cantares 5–6 e 1 Tessalonicenses 4 apontam para a santidade de Deus e nos encorajam a permanecer firmes no caminho do Senhor."
  },
  {
    "date": "2026-07-22",
    "oldTestament": "Cantares 7–8",
    "wisdom": "",
    "newTestament": "1 Tessalonicenses 5",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em Cantares 7–8 e 1 Tessalonicenses 5, a Palavra nos chama a depender da graça de Deus e a transformar a leitura em vida obediente."
  },
  {
    "date": "2026-07-23",
    "oldTestament": "Isaías 1–2",
    "wisdom": "",
    "newTestament": "2 Tessalonicenses 1",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Isaías 1–2 e 2 Tessalonicenses 1 nos ajudam a enxergar o agir de Deus na história e a renovar nossa confiança nele a cada dia."
  },
  {
    "date": "2026-07-24",
    "oldTestament": "Isaías 3–4",
    "wisdom": "",
    "newTestament": "2 Tessalonicenses 2",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de Isaías 3–4 e 2 Tessalonicenses 2 destacam a fidelidade de Deus e nos chamam a responder com fé, obediência e esperança em Cristo."
  },
  {
    "date": "2026-07-25",
    "oldTestament": "Isaías 5–6",
    "wisdom": "",
    "newTestament": "2 Tessalonicenses 3",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em Isaías 5–6 e 2 Tessalonicenses 3, somos lembrados de buscar a direção do Senhor e caminhar com um coração atento à sua Palavra."
  },
  {
    "date": "2026-07-26",
    "oldTestament": "Isaías 7–8",
    "wisdom": "",
    "newTestament": "1 Timóteo 1",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Isaías 7–8 e 1 Timóteo 1 nos convidam a confiar no cuidado de Deus e a viver uma fé prática, perseverante e cheia de esperança."
  },
  {
    "date": "2026-07-27",
    "oldTestament": "Isaías 9–10",
    "wisdom": "",
    "newTestament": "1 Timóteo 2",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de Isaías 9–10 e 1 Timóteo 2 apontam para a santidade de Deus e nos encorajam a permanecer firmes no caminho do Senhor."
  },
  {
    "date": "2026-07-28",
    "oldTestament": "Isaías 11–12",
    "wisdom": "",
    "newTestament": "1 Timóteo 3",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em Isaías 11–12 e 1 Timóteo 3, a Palavra nos chama a depender da graça de Deus e a transformar a leitura em vida obediente."
  },
  {
    "date": "2026-07-29",
    "oldTestament": "Isaías 13–14",
    "wisdom": "",
    "newTestament": "1 Timóteo 4",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Isaías 13–14 e 1 Timóteo 4 nos ajudam a enxergar o agir de Deus na história e a renovar nossa confiança nele a cada dia."
  },
  {
    "date": "2026-07-30",
    "oldTestament": "Isaías 15–16",
    "wisdom": "",
    "newTestament": "1 Timóteo 5",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de Isaías 15–16 e 1 Timóteo 5 destacam a fidelidade de Deus e nos chamam a responder com fé, obediência e esperança em Cristo."
  },
  {
    "date": "2026-07-31",
    "oldTestament": "Isaías 17–18",
    "wisdom": "",
    "newTestament": "1 Timóteo 6",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em Isaías 17–18 e 1 Timóteo 6, somos lembrados de buscar a direção do Senhor e caminhar com um coração atento à sua Palavra."
  },
  {
    "date": "2026-08-01",
    "oldTestament": "Isaías 19–20",
    "wisdom": "",
    "newTestament": "2 Timóteo 1",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Isaías 19–20 e 2 Timóteo 1 nos convidam a confiar no cuidado de Deus e a viver uma fé prática, perseverante e cheia de esperança."
  },
  {
    "date": "2026-08-02",
    "oldTestament": "Isaías 21–22",
    "wisdom": "",
    "newTestament": "2 Timóteo 2",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de Isaías 21–22 e 2 Timóteo 2 apontam para a santidade de Deus e nos encorajam a permanecer firmes no caminho do Senhor."
  },
  {
    "date": "2026-08-03",
    "oldTestament": "Isaías 23–24",
    "wisdom": "",
    "newTestament": "2 Timóteo 3",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em Isaías 23–24 e 2 Timóteo 3, a Palavra nos chama a depender da graça de Deus e a transformar a leitura em vida obediente."
  },
  {
    "date": "2026-08-04",
    "oldTestament": "Isaías 25–26",
    "wisdom": "",
    "newTestament": "2 Timóteo 4",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Isaías 25–26 e 2 Timóteo 4 nos ajudam a enxergar o agir de Deus na história e a renovar nossa confiança nele a cada dia."
  },
  {
    "date": "2026-08-05",
    "oldTestament": "Isaías 27–28",
    "wisdom": "",
    "newTestament": "Tito",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de Isaías 27–28 e Tito destacam a fidelidade de Deus e nos chamam a responder com fé, obediência e esperança em Cristo."
  },
  {
    "date": "2026-08-06",
    "oldTestament": "Isaías 29–30",
    "wisdom": "",
    "newTestament": "Filemom",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em Isaías 29–30 e Filemom, somos lembrados de buscar a direção do Senhor e caminhar com um coração atento à sua Palavra."
  },
  {
    "date": "2026-08-07",
    "oldTestament": "Isaías 31–32",
    "wisdom": "",
    "newTestament": "Hebreus 1",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Isaías 31–32 e Hebreus 1 nos convidam a confiar no cuidado de Deus e a viver uma fé prática, perseverante e cheia de esperança."
  },
  {
    "date": "2026-08-08",
    "oldTestament": "Isaías 33–34",
    "wisdom": "",
    "newTestament": "Hebreus 2",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de Isaías 33–34 e Hebreus 2 apontam para a santidade de Deus e nos encorajam a permanecer firmes no caminho do Senhor."
  },
  {
    "date": "2026-08-09",
    "oldTestament": "Isaías 35–36",
    "wisdom": "",
    "newTestament": "Hebreus 3",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em Isaías 35–36 e Hebreus 3, a Palavra nos chama a depender da graça de Deus e a transformar a leitura em vida obediente."
  },
  {
    "date": "2026-08-10",
    "oldTestament": "Isaías 37–38",
    "wisdom": "",
    "newTestament": "Hebreus 4:1–13",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Isaías 37–38 e Hebreus 4:1–13 nos ajudam a enxergar o agir de Deus na história e a renovar nossa confiança nele a cada dia."
  },
  {
    "date": "2026-08-11",
    "oldTestament": "Isaías 39–40",
    "wisdom": "",
    "newTestament": "Hebreus 4:14–16 + 5:1–10",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de Isaías 39–40 e Hebreus 4:14–16 + 5:1–10 destacam a fidelidade de Deus e nos chamam a responder com fé, obediência e esperança em Cristo."
  },
  {
    "date": "2026-08-12",
    "oldTestament": "Isaías 41–42",
    "wisdom": "",
    "newTestament": "Hebreus 5:11–14 + 6:1–12",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em Isaías 41–42 e Hebreus 5:11–14 + 6:1–12, somos lembrados de buscar a direção do Senhor e caminhar com um coração atento à sua Palavra."
  },
  {
    "date": "2026-08-13",
    "oldTestament": "Isaías 43–44",
    "wisdom": "",
    "newTestament": "Hebreus 6:13–20 + 7:1–10",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Isaías 43–44 e Hebreus 6:13–20 + 7:1–10 nos convidam a confiar no cuidado de Deus e a viver uma fé prática, perseverante e cheia de esperança."
  },
  {
    "date": "2026-08-14",
    "oldTestament": "Isaías 45–46",
    "wisdom": "",
    "newTestament": "Hebreus 7:11–28",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de Isaías 45–46 e Hebreus 7:11–28 apontam para a santidade de Deus e nos encorajam a permanecer firmes no caminho do Senhor."
  },
  {
    "date": "2026-08-15",
    "oldTestament": "Isaías 47–48",
    "wisdom": "",
    "newTestament": "Hebreus 8",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em Isaías 47–48 e Hebreus 8, a Palavra nos chama a depender da graça de Deus e a transformar a leitura em vida obediente."
  },
  {
    "date": "2026-08-16",
    "oldTestament": "Isaías 49–50",
    "wisdom": "",
    "newTestament": "Hebreus 9:1–14",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Isaías 49–50 e Hebreus 9:1–14 nos ajudam a enxergar o agir de Deus na história e a renovar nossa confiança nele a cada dia."
  },
  {
    "date": "2026-08-17",
    "oldTestament": "Isaías 51–52",
    "wisdom": "",
    "newTestament": "Hebreus 9:15–28",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de Isaías 51–52 e Hebreus 9:15–28 destacam a fidelidade de Deus e nos chamam a responder com fé, obediência e esperança em Cristo."
  },
  {
    "date": "2026-08-18",
    "oldTestament": "Isaías 53–54",
    "wisdom": "",
    "newTestament": "Hebreus 10:1–18",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em Isaías 53–54 e Hebreus 10:1–18, somos lembrados de buscar a direção do Senhor e caminhar com um coração atento à sua Palavra."
  },
  {
    "date": "2026-08-19",
    "oldTestament": "Isaías 55–56",
    "wisdom": "",
    "newTestament": "Hebreus 10:19–39",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Isaías 55–56 e Hebreus 10:19–39 nos convidam a confiar no cuidado de Deus e a viver uma fé prática, perseverante e cheia de esperança."
  },
  {
    "date": "2026-08-20",
    "oldTestament": "Isaías 57–58",
    "wisdom": "",
    "newTestament": "Hebreus 11:1–22",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de Isaías 57–58 e Hebreus 11:1–22 apontam para a santidade de Deus e nos encorajam a permanecer firmes no caminho do Senhor."
  },
  {
    "date": "2026-08-21",
    "oldTestament": "Isaías 59–60",
    "wisdom": "",
    "newTestament": "Hebreus 11:23–40",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em Isaías 59–60 e Hebreus 11:23–40, a Palavra nos chama a depender da graça de Deus e a transformar a leitura em vida obediente."
  },
  {
    "date": "2026-08-22",
    "oldTestament": "Isaías 61–62",
    "wisdom": "",
    "newTestament": "Hebreus 12:1–13",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Isaías 61–62 e Hebreus 12:1–13 nos ajudam a enxergar o agir de Deus na história e a renovar nossa confiança nele a cada dia."
  },
  {
    "date": "2026-08-23",
    "oldTestament": "Isaías 63–64",
    "wisdom": "",
    "newTestament": "Hebreus 12:14–29",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de Isaías 63–64 e Hebreus 12:14–29 destacam a fidelidade de Deus e nos chamam a responder com fé, obediência e esperança em Cristo."
  },
  {
    "date": "2026-08-24",
    "oldTestament": "Isaías 65–66",
    "wisdom": "",
    "newTestament": "Hebreus 13",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em Isaías 65–66 e Hebreus 13, somos lembrados de buscar a direção do Senhor e caminhar com um coração atento à sua Palavra."
  },
  {
    "date": "2026-08-25",
    "oldTestament": "Jeremias 1–2",
    "wisdom": "",
    "newTestament": "Tiago 1",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Jeremias 1–2 e Tiago 1 nos convidam a confiar no cuidado de Deus e a viver uma fé prática, perseverante e cheia de esperança."
  },
  {
    "date": "2026-08-26",
    "oldTestament": "Jeremias 3–4",
    "wisdom": "",
    "newTestament": "Tiago 2",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de Jeremias 3–4 e Tiago 2 apontam para a santidade de Deus e nos encorajam a permanecer firmes no caminho do Senhor."
  },
  {
    "date": "2026-08-27",
    "oldTestament": "Jeremias 5–6",
    "wisdom": "",
    "newTestament": "Tiago 3",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em Jeremias 5–6 e Tiago 3, a Palavra nos chama a depender da graça de Deus e a transformar a leitura em vida obediente."
  },
  {
    "date": "2026-08-28",
    "oldTestament": "Jeremias 7–8",
    "wisdom": "",
    "newTestament": "Tiago 4",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Jeremias 7–8 e Tiago 4 nos ajudam a enxergar o agir de Deus na história e a renovar nossa confiança nele a cada dia."
  },
  {
    "date": "2026-08-29",
    "oldTestament": "Jeremias 9–10",
    "wisdom": "",
    "newTestament": "Tiago 5",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de Jeremias 9–10 e Tiago 5 destacam a fidelidade de Deus e nos chamam a responder com fé, obediência e esperança em Cristo."
  },
  {
    "date": "2026-08-30",
    "oldTestament": "Jeremias 11–12",
    "wisdom": "",
    "newTestament": "1 Pedro 1:1–12",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em Jeremias 11–12 e 1 Pedro 1:1–12, somos lembrados de buscar a direção do Senhor e caminhar com um coração atento à sua Palavra."
  },
  {
    "date": "2026-08-31",
    "oldTestament": "Jeremias 13–14",
    "wisdom": "",
    "newTestament": "1 Pedro 1:13–25",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Jeremias 13–14 e 1 Pedro 1:13–25 nos convidam a confiar no cuidado de Deus e a viver uma fé prática, perseverante e cheia de esperança."
  },
  {
    "date": "2026-09-01",
    "oldTestament": "Jeremias 15–16",
    "wisdom": "",
    "newTestament": "1 Pedro 2",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de Jeremias 15–16 e 1 Pedro 2 apontam para a santidade de Deus e nos encorajam a permanecer firmes no caminho do Senhor."
  },
  {
    "date": "2026-09-02",
    "oldTestament": "Jeremias 17–18",
    "wisdom": "",
    "newTestament": "1 Pedro 3",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em Jeremias 17–18 e 1 Pedro 3, a Palavra nos chama a depender da graça de Deus e a transformar a leitura em vida obediente."
  },
  {
    "date": "2026-09-03",
    "oldTestament": "Jeremias 19–20",
    "wisdom": "",
    "newTestament": "1 Pedro 4",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Jeremias 19–20 e 1 Pedro 4 nos ajudam a enxergar o agir de Deus na história e a renovar nossa confiança nele a cada dia."
  },
  {
    "date": "2026-09-04",
    "oldTestament": "Jeremias 21–22",
    "wisdom": "",
    "newTestament": "1 Pedro 5",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de Jeremias 21–22 e 1 Pedro 5 destacam a fidelidade de Deus e nos chamam a responder com fé, obediência e esperança em Cristo."
  },
  {
    "date": "2026-09-05",
    "oldTestament": "Jeremias 23–24",
    "wisdom": "",
    "newTestament": "2 Pedro 1",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em Jeremias 23–24 e 2 Pedro 1, somos lembrados de buscar a direção do Senhor e caminhar com um coração atento à sua Palavra."
  },
  {
    "date": "2026-09-06",
    "oldTestament": "Jeremias 25–26",
    "wisdom": "",
    "newTestament": "2 Pedro 2",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Jeremias 25–26 e 2 Pedro 2 nos convidam a confiar no cuidado de Deus e a viver uma fé prática, perseverante e cheia de esperança."
  },
  {
    "date": "2026-09-07",
    "oldTestament": "Jeremias 27–28",
    "wisdom": "",
    "newTestament": "2 Pedro 3",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de Jeremias 27–28 e 2 Pedro 3 apontam para a santidade de Deus e nos encorajam a permanecer firmes no caminho do Senhor."
  },
  {
    "date": "2026-09-08",
    "oldTestament": "Jeremias 29–30",
    "wisdom": "",
    "newTestament": "1 João 1",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em Jeremias 29–30 e 1 João 1, a Palavra nos chama a depender da graça de Deus e a transformar a leitura em vida obediente."
  },
  {
    "date": "2026-09-09",
    "oldTestament": "Jeremias 31–32",
    "wisdom": "",
    "newTestament": "1 João 2:1–17",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Jeremias 31–32 e 1 João 2:1–17 nos ajudam a enxergar o agir de Deus na história e a renovar nossa confiança nele a cada dia."
  },
  {
    "date": "2026-09-10",
    "oldTestament": "Jeremias 33–34",
    "wisdom": "",
    "newTestament": "1 João 2:18–29",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de Jeremias 33–34 e 1 João 2:18–29 destacam a fidelidade de Deus e nos chamam a responder com fé, obediência e esperança em Cristo."
  },
  {
    "date": "2026-09-11",
    "oldTestament": "Jeremias 35–36",
    "wisdom": "",
    "newTestament": "1 João 3",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em Jeremias 35–36 e 1 João 3, somos lembrados de buscar a direção do Senhor e caminhar com um coração atento à sua Palavra."
  },
  {
    "date": "2026-09-12",
    "oldTestament": "Jeremias 37–38",
    "wisdom": "",
    "newTestament": "1 João 4",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Jeremias 37–38 e 1 João 4 nos convidam a confiar no cuidado de Deus e a viver uma fé prática, perseverante e cheia de esperança."
  },
  {
    "date": "2026-09-13",
    "oldTestament": "Jeremias 39–40",
    "wisdom": "",
    "newTestament": "1 João 5",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de Jeremias 39–40 e 1 João 5 apontam para a santidade de Deus e nos encorajam a permanecer firmes no caminho do Senhor."
  },
  {
    "date": "2026-09-14",
    "oldTestament": "Jeremias 41–42",
    "wisdom": "",
    "newTestament": "2 João",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em Jeremias 41–42 e 2 João, a Palavra nos chama a depender da graça de Deus e a transformar a leitura em vida obediente."
  },
  {
    "date": "2026-09-15",
    "oldTestament": "Jeremias 43–44",
    "wisdom": "",
    "newTestament": "3 João",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Jeremias 43–44 e 3 João nos ajudam a enxergar o agir de Deus na história e a renovar nossa confiança nele a cada dia."
  },
  {
    "date": "2026-09-16",
    "oldTestament": "Jeremias 45–46",
    "wisdom": "",
    "newTestament": "Judas",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de Jeremias 45–46 e Judas destacam a fidelidade de Deus e nos chamam a responder com fé, obediência e esperança em Cristo."
  },
  {
    "date": "2026-09-17",
    "oldTestament": "Jeremias 47–48",
    "wisdom": "",
    "newTestament": "Apocalipse 1",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em Jeremias 47–48 e Apocalipse 1, somos lembrados de buscar a direção do Senhor e caminhar com um coração atento à sua Palavra."
  },
  {
    "date": "2026-09-18",
    "oldTestament": "Jeremias 49–50",
    "wisdom": "",
    "newTestament": "Apocalipse 2",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Jeremias 49–50 e Apocalipse 2 nos convidam a confiar no cuidado de Deus e a viver uma fé prática, perseverante e cheia de esperança."
  },
  {
    "date": "2026-09-19",
    "oldTestament": "Jeremias 51–52",
    "wisdom": "",
    "newTestament": "Apocalipse 3",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de Jeremias 51–52 e Apocalipse 3 apontam para a santidade de Deus e nos encorajam a permanecer firmes no caminho do Senhor."
  },
  {
    "date": "2026-09-20",
    "oldTestament": "Lamentações 1–2",
    "wisdom": "",
    "newTestament": "Apocalipse 4",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em Lamentações 1–2 e Apocalipse 4, a Palavra nos chama a depender da graça de Deus e a transformar a leitura em vida obediente."
  },
  {
    "date": "2026-09-21",
    "oldTestament": "Lamentações 3–5",
    "wisdom": "",
    "newTestament": "Apocalipse 5",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Lamentações 3–5 e Apocalipse 5 nos ajudam a enxergar o agir de Deus na história e a renovar nossa confiança nele a cada dia."
  },
  {
    "date": "2026-09-22",
    "oldTestament": "Ezequiel 1–2",
    "wisdom": "",
    "newTestament": "Apocalipse 6",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de Ezequiel 1–2 e Apocalipse 6 destacam a fidelidade de Deus e nos chamam a responder com fé, obediência e esperança em Cristo."
  },
  {
    "date": "2026-09-23",
    "oldTestament": "Ezequiel 3–4",
    "wisdom": "",
    "newTestament": "Apocalipse 7",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em Ezequiel 3–4 e Apocalipse 7, somos lembrados de buscar a direção do Senhor e caminhar com um coração atento à sua Palavra."
  },
  {
    "date": "2026-09-24",
    "oldTestament": "Ezequiel 5–6",
    "wisdom": "",
    "newTestament": "Apocalipse 8",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Ezequiel 5–6 e Apocalipse 8 nos convidam a confiar no cuidado de Deus e a viver uma fé prática, perseverante e cheia de esperança."
  },
  {
    "date": "2026-09-25",
    "oldTestament": "Ezequiel 7–8",
    "wisdom": "",
    "newTestament": "Apocalipse 9",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de Ezequiel 7–8 e Apocalipse 9 apontam para a santidade de Deus e nos encorajam a permanecer firmes no caminho do Senhor."
  },
  {
    "date": "2026-09-26",
    "oldTestament": "Ezequiel 9–10",
    "wisdom": "",
    "newTestament": "Apocalipse 10",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em Ezequiel 9–10 e Apocalipse 10, a Palavra nos chama a depender da graça de Deus e a transformar a leitura em vida obediente."
  },
  {
    "date": "2026-09-27",
    "oldTestament": "Ezequiel 11–12",
    "wisdom": "",
    "newTestament": "Apocalipse 11",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Ezequiel 11–12 e Apocalipse 11 nos ajudam a enxergar o agir de Deus na história e a renovar nossa confiança nele a cada dia."
  },
  {
    "date": "2026-09-28",
    "oldTestament": "Ezequiel 13–14",
    "wisdom": "",
    "newTestament": "Apocalipse 12",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de Ezequiel 13–14 e Apocalipse 12 destacam a fidelidade de Deus e nos chamam a responder com fé, obediência e esperança em Cristo."
  },
  {
    "date": "2026-09-29",
    "oldTestament": "Ezequiel 15–16",
    "wisdom": "",
    "newTestament": "Apocalipse 13",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em Ezequiel 15–16 e Apocalipse 13, somos lembrados de buscar a direção do Senhor e caminhar com um coração atento à sua Palavra."
  },
  {
    "date": "2026-09-30",
    "oldTestament": "Ezequiel 17–18",
    "wisdom": "",
    "newTestament": "Apocalipse 14",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Ezequiel 17–18 e Apocalipse 14 nos convidam a confiar no cuidado de Deus e a viver uma fé prática, perseverante e cheia de esperança."
  },
  {
    "date": "2026-10-01",
    "oldTestament": "Ezequiel 19–20",
    "wisdom": "",
    "newTestament": "Apocalipse 15",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de Ezequiel 19–20 e Apocalipse 15 apontam para a santidade de Deus e nos encorajam a permanecer firmes no caminho do Senhor."
  },
  {
    "date": "2026-10-02",
    "oldTestament": "Ezequiel 21–22",
    "wisdom": "",
    "newTestament": "Apocalipse 16",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em Ezequiel 21–22 e Apocalipse 16, a Palavra nos chama a depender da graça de Deus e a transformar a leitura em vida obediente."
  },
  {
    "date": "2026-10-03",
    "oldTestament": "Ezequiel 23–24",
    "wisdom": "",
    "newTestament": "Apocalipse 17",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Ezequiel 23–24 e Apocalipse 17 nos ajudam a enxergar o agir de Deus na história e a renovar nossa confiança nele a cada dia."
  },
  {
    "date": "2026-10-04",
    "oldTestament": "Ezequiel 25–26",
    "wisdom": "",
    "newTestament": "Apocalipse 18",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de Ezequiel 25–26 e Apocalipse 18 destacam a fidelidade de Deus e nos chamam a responder com fé, obediência e esperança em Cristo."
  },
  {
    "date": "2026-10-05",
    "oldTestament": "Ezequiel 27–28",
    "wisdom": "",
    "newTestament": "Apocalipse 19",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em Ezequiel 27–28 e Apocalipse 19, somos lembrados de buscar a direção do Senhor e caminhar com um coração atento à sua Palavra."
  },
  {
    "date": "2026-10-06",
    "oldTestament": "Ezequiel 29–30",
    "wisdom": "",
    "newTestament": "Apocalipse 20",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Ezequiel 29–30 e Apocalipse 20 nos convidam a confiar no cuidado de Deus e a viver uma fé prática, perseverante e cheia de esperança."
  },
  {
    "date": "2026-10-07",
    "oldTestament": "Ezequiel 31–32",
    "wisdom": "",
    "newTestament": "Apocalipse 21",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de Ezequiel 31–32 e Apocalipse 21 apontam para a santidade de Deus e nos encorajam a permanecer firmes no caminho do Senhor."
  },
  {
    "date": "2026-10-08",
    "oldTestament": "Ezequiel 33–34",
    "wisdom": "",
    "newTestament": "Apocalipse 22",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em Ezequiel 33–34 e Apocalipse 22, a Palavra nos chama a depender da graça de Deus e a transformar a leitura em vida obediente."
  },
  {
    "date": "2026-10-09",
    "oldTestament": "Ezequiel 35–36",
    "wisdom": "",
    "newTestament": "",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Ezequiel 35–36 nos ajudam a enxergar o agir de Deus na história e a renovar nossa confiança nele a cada dia."
  },
  {
    "date": "2026-10-10",
    "oldTestament": "Ezequiel 37–38",
    "wisdom": "",
    "newTestament": "",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de Ezequiel 37–38 destacam a fidelidade de Deus e nos chamam a responder com fé, obediência e esperança em Cristo."
  },
  {
    "date": "2026-10-11",
    "oldTestament": "Ezequiel 39–40",
    "wisdom": "",
    "newTestament": "",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em Ezequiel 39–40, somos lembrados de buscar a direção do Senhor e caminhar com um coração atento à sua Palavra."
  },
  {
    "date": "2026-10-12",
    "oldTestament": "Ezequiel 41–42",
    "wisdom": "",
    "newTestament": "",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Ezequiel 41–42 nos convidam a confiar no cuidado de Deus e a viver uma fé prática, perseverante e cheia de esperança."
  },
  {
    "date": "2026-10-13",
    "oldTestament": "Ezequiel 43–44",
    "wisdom": "",
    "newTestament": "",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de Ezequiel 43–44 apontam para a santidade de Deus e nos encorajam a permanecer firmes no caminho do Senhor."
  },
  {
    "date": "2026-10-14",
    "oldTestament": "Ezequiel 45–46",
    "wisdom": "",
    "newTestament": "",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em Ezequiel 45–46, a Palavra nos chama a depender da graça de Deus e a transformar a leitura em vida obediente."
  },
  {
    "date": "2026-10-15",
    "oldTestament": "Ezequiel 47–48",
    "wisdom": "",
    "newTestament": "",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Ezequiel 47–48 nos ajudam a enxergar o agir de Deus na história e a renovar nossa confiança nele a cada dia."
  },
  {
    "date": "2026-10-16",
    "oldTestament": "Daniel 1–2",
    "wisdom": "",
    "newTestament": "",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de Daniel 1–2 destacam a fidelidade de Deus e nos chamam a responder com fé, obediência e esperança em Cristo."
  },
  {
    "date": "2026-10-17",
    "oldTestament": "Daniel 3–4",
    "wisdom": "",
    "newTestament": "",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em Daniel 3–4, somos lembrados de buscar a direção do Senhor e caminhar com um coração atento à sua Palavra."
  },
  {
    "date": "2026-10-18",
    "oldTestament": "Daniel 5–6",
    "wisdom": "",
    "newTestament": "",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Daniel 5–6 nos convidam a confiar no cuidado de Deus e a viver uma fé prática, perseverante e cheia de esperança."
  },
  {
    "date": "2026-10-19",
    "oldTestament": "Daniel 7–8",
    "wisdom": "",
    "newTestament": "",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de Daniel 7–8 apontam para a santidade de Deus e nos encorajam a permanecer firmes no caminho do Senhor."
  },
  {
    "date": "2026-10-20",
    "oldTestament": "Daniel 9–10",
    "wisdom": "",
    "newTestament": "",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em Daniel 9–10, a Palavra nos chama a depender da graça de Deus e a transformar a leitura em vida obediente."
  },
  {
    "date": "2026-10-21",
    "oldTestament": "Daniel 11–12",
    "wisdom": "",
    "newTestament": "",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Daniel 11–12 nos ajudam a enxergar o agir de Deus na história e a renovar nossa confiança nele a cada dia."
  },
  {
    "date": "2026-10-22",
    "oldTestament": "Oséias 1–2",
    "wisdom": "",
    "newTestament": "",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de Oséias 1–2 destacam a fidelidade de Deus e nos chamam a responder com fé, obediência e esperança em Cristo."
  },
  {
    "date": "2026-10-23",
    "oldTestament": "Oséias 3–4",
    "wisdom": "",
    "newTestament": "",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em Oséias 3–4, somos lembrados de buscar a direção do Senhor e caminhar com um coração atento à sua Palavra."
  },
  {
    "date": "2026-10-24",
    "oldTestament": "Oséias 5–6",
    "wisdom": "",
    "newTestament": "",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Oséias 5–6 nos convidam a confiar no cuidado de Deus e a viver uma fé prática, perseverante e cheia de esperança."
  },
  {
    "date": "2026-10-25",
    "oldTestament": "Oséias 7–8",
    "wisdom": "",
    "newTestament": "",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de Oséias 7–8 apontam para a santidade de Deus e nos encorajam a permanecer firmes no caminho do Senhor."
  },
  {
    "date": "2026-10-26",
    "oldTestament": "Oséias 9–10",
    "wisdom": "",
    "newTestament": "",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em Oséias 9–10, a Palavra nos chama a depender da graça de Deus e a transformar a leitura em vida obediente."
  },
  {
    "date": "2026-10-27",
    "oldTestament": "Oséias 11–12",
    "wisdom": "",
    "newTestament": "",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Oséias 11–12 nos ajudam a enxergar o agir de Deus na história e a renovar nossa confiança nele a cada dia."
  },
  {
    "date": "2026-10-28",
    "oldTestament": "Oséias 13–14",
    "wisdom": "",
    "newTestament": "",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de Oséias 13–14 destacam a fidelidade de Deus e nos chamam a responder com fé, obediência e esperança em Cristo."
  },
  {
    "date": "2026-10-29",
    "oldTestament": "Joel 1–2",
    "wisdom": "",
    "newTestament": "",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em Joel 1–2, somos lembrados de buscar a direção do Senhor e caminhar com um coração atento à sua Palavra."
  },
  {
    "date": "2026-10-30",
    "oldTestament": "Joel 3",
    "wisdom": "",
    "newTestament": "",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Joel 3 nos convidam a confiar no cuidado de Deus e a viver uma fé prática, perseverante e cheia de esperança."
  },
  {
    "date": "2026-10-31",
    "oldTestament": "Amós 1–2",
    "wisdom": "",
    "newTestament": "",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de Amós 1–2 apontam para a santidade de Deus e nos encorajam a permanecer firmes no caminho do Senhor."
  },
  {
    "date": "2026-11-01",
    "oldTestament": "Amós 3–4",
    "wisdom": "",
    "newTestament": "",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em Amós 3–4, a Palavra nos chama a depender da graça de Deus e a transformar a leitura em vida obediente."
  },
  {
    "date": "2026-11-02",
    "oldTestament": "Amós 5–6",
    "wisdom": "",
    "newTestament": "",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Amós 5–6 nos ajudam a enxergar o agir de Deus na história e a renovar nossa confiança nele a cada dia."
  },
  {
    "date": "2026-11-03",
    "oldTestament": "Amós 7–9",
    "wisdom": "",
    "newTestament": "",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de Amós 7–9 destacam a fidelidade de Deus e nos chamam a responder com fé, obediência e esperança em Cristo."
  },
  {
    "date": "2026-11-04",
    "oldTestament": "Obadias",
    "wisdom": "",
    "newTestament": "",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em Obadias, somos lembrados de buscar a direção do Senhor e caminhar com um coração atento à sua Palavra."
  },
  {
    "date": "2026-11-05",
    "oldTestament": "Jonas 1–2",
    "wisdom": "",
    "newTestament": "",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Jonas 1–2 nos convidam a confiar no cuidado de Deus e a viver uma fé prática, perseverante e cheia de esperança."
  },
  {
    "date": "2026-11-06",
    "oldTestament": "Jonas 3–4",
    "wisdom": "",
    "newTestament": "",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de Jonas 3–4 apontam para a santidade de Deus e nos encorajam a permanecer firmes no caminho do Senhor."
  },
  {
    "date": "2026-11-07",
    "oldTestament": "Miqueias 1–2",
    "wisdom": "",
    "newTestament": "",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em Miqueias 1–2, a Palavra nos chama a depender da graça de Deus e a transformar a leitura em vida obediente."
  },
  {
    "date": "2026-11-08",
    "oldTestament": "Miqueias 3–4",
    "wisdom": "",
    "newTestament": "",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Miqueias 3–4 nos ajudam a enxergar o agir de Deus na história e a renovar nossa confiança nele a cada dia."
  },
  {
    "date": "2026-11-09",
    "oldTestament": "Miqueias 5–7",
    "wisdom": "",
    "newTestament": "",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de Miqueias 5–7 destacam a fidelidade de Deus e nos chamam a responder com fé, obediência e esperança em Cristo."
  },
  {
    "date": "2026-11-10",
    "oldTestament": "Naum 1–3",
    "wisdom": "",
    "newTestament": "",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em Naum 1–3, somos lembrados de buscar a direção do Senhor e caminhar com um coração atento à sua Palavra."
  },
  {
    "date": "2026-11-11",
    "oldTestament": "Habacuque 1–3",
    "wisdom": "",
    "newTestament": "",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Habacuque 1–3 nos convidam a confiar no cuidado de Deus e a viver uma fé prática, perseverante e cheia de esperança."
  },
  {
    "date": "2026-11-12",
    "oldTestament": "Sofonias 1–3",
    "wisdom": "",
    "newTestament": "",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de Sofonias 1–3 apontam para a santidade de Deus e nos encorajam a permanecer firmes no caminho do Senhor."
  },
  {
    "date": "2026-11-13",
    "oldTestament": "Ageu 1–2",
    "wisdom": "",
    "newTestament": "",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em Ageu 1–2, a Palavra nos chama a depender da graça de Deus e a transformar a leitura em vida obediente."
  },
  {
    "date": "2026-11-14",
    "oldTestament": "Zacarias 1–2",
    "wisdom": "",
    "newTestament": "",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Zacarias 1–2 nos ajudam a enxergar o agir de Deus na história e a renovar nossa confiança nele a cada dia."
  },
  {
    "date": "2026-11-15",
    "oldTestament": "Zacarias 3–4",
    "wisdom": "",
    "newTestament": "",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de Zacarias 3–4 destacam a fidelidade de Deus e nos chamam a responder com fé, obediência e esperança em Cristo."
  },
  {
    "date": "2026-11-16",
    "oldTestament": "Zacarias 5–6",
    "wisdom": "",
    "newTestament": "",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em Zacarias 5–6, somos lembrados de buscar a direção do Senhor e caminhar com um coração atento à sua Palavra."
  },
  {
    "date": "2026-11-17",
    "oldTestament": "Zacarias 7–8",
    "wisdom": "",
    "newTestament": "",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Zacarias 7–8 nos convidam a confiar no cuidado de Deus e a viver uma fé prática, perseverante e cheia de esperança."
  },
  {
    "date": "2026-11-18",
    "oldTestament": "Zacarias 9–10",
    "wisdom": "",
    "newTestament": "",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de Zacarias 9–10 apontam para a santidade de Deus e nos encorajam a permanecer firmes no caminho do Senhor."
  },
  {
    "date": "2026-11-19",
    "oldTestament": "Zacarias 11–12",
    "wisdom": "",
    "newTestament": "",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em Zacarias 11–12, a Palavra nos chama a depender da graça de Deus e a transformar a leitura em vida obediente."
  },
  {
    "date": "2026-11-20",
    "oldTestament": "Zacarias 13–14",
    "wisdom": "",
    "newTestament": "",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Zacarias 13–14 nos ajudam a enxergar o agir de Deus na história e a renovar nossa confiança nele a cada dia."
  },
  {
    "date": "2026-11-21",
    "oldTestament": "Malaquias 1",
    "wisdom": "",
    "newTestament": "",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de Malaquias 1 destacam a fidelidade de Deus e nos chamam a responder com fé, obediência e esperança em Cristo."
  },
  {
    "date": "2026-11-22",
    "oldTestament": "Malaquias 2",
    "wisdom": "",
    "newTestament": "",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em Malaquias 2, somos lembrados de buscar a direção do Senhor e caminhar com um coração atento à sua Palavra."
  },
  {
    "date": "2026-11-23",
    "oldTestament": "Malaquias 3:1–6",
    "wisdom": "",
    "newTestament": "",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Malaquias 3:1–6 nos convidam a confiar no cuidado de Deus e a viver uma fé prática, perseverante e cheia de esperança."
  },
  {
    "date": "2026-11-24",
    "oldTestament": "Malaquias 3:7–12",
    "wisdom": "",
    "newTestament": "",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de Malaquias 3:7–12 apontam para a santidade de Deus e nos encorajam a permanecer firmes no caminho do Senhor."
  },
  {
    "date": "2026-11-25",
    "oldTestament": "Malaquias 3:13–18",
    "wisdom": "",
    "newTestament": "",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em Malaquias 3:13–18, a Palavra nos chama a depender da graça de Deus e a transformar a leitura em vida obediente."
  },
  {
    "date": "2026-11-26",
    "oldTestament": "Malaquias 4:1–3",
    "wisdom": "",
    "newTestament": "",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Malaquias 4:1–3 nos ajudam a enxergar o agir de Deus na história e a renovar nossa confiança nele a cada dia."
  },
  {
    "date": "2026-11-27",
    "oldTestament": "Zacarias 9–10",
    "wisdom": "",
    "newTestament": "",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de Zacarias 9–10 destacam a fidelidade de Deus e nos chamam a responder com fé, obediência e esperança em Cristo."
  },
  {
    "date": "2026-11-28",
    "oldTestament": "Zacarias 11–12",
    "wisdom": "",
    "newTestament": "",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em Zacarias 11–12, somos lembrados de buscar a direção do Senhor e caminhar com um coração atento à sua Palavra."
  },
  {
    "date": "2026-11-29",
    "oldTestament": "Zacarias 13–14",
    "wisdom": "",
    "newTestament": "",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Zacarias 13–14 nos convidam a confiar no cuidado de Deus e a viver uma fé prática, perseverante e cheia de esperança."
  },
  {
    "date": "2026-11-30",
    "oldTestament": "Ageu 1–2",
    "wisdom": "",
    "newTestament": "",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de Ageu 1–2 apontam para a santidade de Deus e nos encorajam a permanecer firmes no caminho do Senhor."
  },
  {
    "date": "2026-12-01",
    "oldTestament": "Obadias 1",
    "wisdom": "",
    "newTestament": "Lucas 19 · João 12",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em Obadias 1 e Lucas 19 · João 12, a Palavra nos chama a depender da graça de Deus e a transformar a leitura em vida obediente."
  },
  {
    "date": "2026-12-02",
    "oldTestament": "Jonas 1–2",
    "wisdom": "",
    "newTestament": "Mateus 21",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Jonas 1–2 e Mateus 21 nos ajudam a enxergar o agir de Deus na história e a renovar nossa confiança nele a cada dia."
  },
  {
    "date": "2026-12-03",
    "oldTestament": "Jonas 3–4",
    "wisdom": "",
    "newTestament": "Marcos 11",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de Jonas 3–4 e Marcos 11 destacam a fidelidade de Deus e nos chamam a responder com fé, obediência e esperança em Cristo."
  },
  {
    "date": "2026-12-04",
    "oldTestament": "Miqueias 1–2",
    "wisdom": "",
    "newTestament": "Mateus 22",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em Miqueias 1–2 e Mateus 22, somos lembrados de buscar a direção do Senhor e caminhar com um coração atento à sua Palavra."
  },
  {
    "date": "2026-12-05",
    "oldTestament": "Miqueias 3–4",
    "wisdom": "",
    "newTestament": "Mateus 23",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Miqueias 3–4 e Mateus 23 nos convidam a confiar no cuidado de Deus e a viver uma fé prática, perseverante e cheia de esperança."
  },
  {
    "date": "2026-12-06",
    "oldTestament": "Miqueias 5–7",
    "wisdom": "",
    "newTestament": "Mateus 24",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de Miqueias 5–7 e Mateus 24 apontam para a santidade de Deus e nos encorajam a permanecer firmes no caminho do Senhor."
  },
  {
    "date": "2026-12-07",
    "oldTestament": "Naum 1–3",
    "wisdom": "",
    "newTestament": "Mateus 25",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em Naum 1–3 e Mateus 25, a Palavra nos chama a depender da graça de Deus e a transformar a leitura em vida obediente."
  },
  {
    "date": "2026-12-08",
    "oldTestament": "Habacuque 1–3",
    "wisdom": "",
    "newTestament": "Marcos 14",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Habacuque 1–3 e Marcos 14 nos ajudam a enxergar o agir de Deus na história e a renovar nossa confiança nele a cada dia."
  },
  {
    "date": "2026-12-09",
    "oldTestament": "Sofonias 1–3",
    "wisdom": "",
    "newTestament": "João 13",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de Sofonias 1–3 e João 13 destacam a fidelidade de Deus e nos chamam a responder com fé, obediência e esperança em Cristo."
  },
  {
    "date": "2026-12-10",
    "oldTestament": "Ageu 1–2",
    "wisdom": "",
    "newTestament": "João 14",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em Ageu 1–2 e João 14, somos lembrados de buscar a direção do Senhor e caminhar com um coração atento à sua Palavra."
  },
  {
    "date": "2026-12-11",
    "oldTestament": "Zacarias 1–7",
    "wisdom": "",
    "newTestament": "João 18",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Zacarias 1–7 e João 18 nos convidam a confiar no cuidado de Deus e a viver uma fé prática, perseverante e cheia de esperança."
  },
  {
    "date": "2026-12-12",
    "oldTestament": "Zacarias 8–14",
    "wisdom": "",
    "newTestament": "João 19",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "As leituras de Zacarias 8–14 e João 19 apontam para a santidade de Deus e nos encorajam a permanecer firmes no caminho do Senhor."
  },
  {
    "date": "2026-12-13",
    "oldTestament": "Malaquias 4:4–6",
    "wisdom": "",
    "newTestament": "João 20",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Em Malaquias 4:4–6 e João 20, a Palavra nos chama a depender da graça de Deus e a transformar a leitura em vida obediente."
  }
];
