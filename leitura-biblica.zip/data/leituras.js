window.LEITURAS_DATA = [
  {
    "date": "2026-07-16",
    "oldTestament": "Eclesiastes 7-8",
    "wisdom": "",
    "newTestament": "Colossenses 3",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "Eclesiastes ensina que a verdadeira sabedoria molda a maneira como vivemos. Colossenses nos chama a buscar as coisas do alto e a revestir-nos do novo homem. Uma vida transformada comeca quando nossa mente e nosso coracao estao firmados em Cristo."
  },
  {
    "date": "2026-07-17",
    "oldTestament": "Eclesiastes 9-10",
    "wisdom": "",
    "newTestament": "Colossenses 4",
    "oldText": "",
    "wisdomText": "",
    "newText": "",
    "message": "A vida e breve, mas a Palavra nos chama a viver com discernimento, gratidao e perseveranca. Que nossas palavras sejam cheias de graca e que cada atitude revele Cristo."
  }
];
